enum Type {
    INTEGER,
    OBJECT
}
